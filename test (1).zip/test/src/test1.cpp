#include<iostream>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>

using namespace std;
int main()
{
        int p,q,pid,status, exitstrat;

        pid = fork();

        if (pid ==0)
        {
                cout<<"child strats"<<endl;
                for(p=1;p=200;p++)
                {
                        if(p%2 != 0)
                        {
                                cout<<"odd number"<<p<<endl;
                        }
                cout<<"the child ends"<<endl;
                }
        }
        else
        {
                cout<<"parents strats"<<endl;
                for(q=0;q<=200;q++)
                {
                        if(j%2 == 0)
                        {
                                cout<<"even number"<<q<<endl;
                        }
                }
        }
        wait(0);
        cout<<"the parent ends"<<endl;
        return 0;
}
