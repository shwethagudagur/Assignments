cc = g++
INC =./inc
OBJ = ./obj
SRC = ./src
BIN = ./bin



LFLAGS = -O
CFLAGS = -c -g -Wall -Werror
IFLAGS = -I$(INC)
CVFLAGS = -v --tool=memcheck --leak-check=full --show -reachable=yes --log-file=valclinet

all: $(BIN)/app valgrind


$(BIN)/app: $(OBJ)/test.o
         $(CC) $(LFLAGS) $(BIN)/app $(OBJ)

$(OBJ)/test1.o:$(SRC)/test1.cpp
        $(CC) $(CFLAGS) $(IFLAGS) $(SRC)/test -o $(OBJ)/test

clean:
       @echo"cleaning the project"
       rm -f $(OBJ)
	rm -f a.out
	rm -f $(BIN)/app

valgrind:
  
     valgrind --leak-check=full $(BIN)/app
     mv valgrind $(BIN)


